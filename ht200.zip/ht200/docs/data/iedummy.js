//definining html5 elements for dumb browsers like IE

document.createElement('article');
document.createElement('nav');
document.createElement('footer');
document.createElement('section');
document.createElement('time');